/* */ 
module.exports = { "default": require("core-js/library/fn/number/is-finite"), __esModule: true };