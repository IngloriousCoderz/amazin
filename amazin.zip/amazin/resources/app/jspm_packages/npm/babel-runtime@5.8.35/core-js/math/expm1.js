/* */ 
module.exports = { "default": require("core-js/library/fn/math/expm1"), __esModule: true };