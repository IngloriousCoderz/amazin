/* */ 
module.exports = { "default": require("core-js/library/fn/number/epsilon"), __esModule: true };