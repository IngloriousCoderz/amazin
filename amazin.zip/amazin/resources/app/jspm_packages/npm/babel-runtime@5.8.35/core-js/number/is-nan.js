/* */ 
module.exports = { "default": require("core-js/library/fn/number/is-nan"), __esModule: true };