/* */ 
module.exports = { "default": require("core-js/library/fn/array/join"), __esModule: true };