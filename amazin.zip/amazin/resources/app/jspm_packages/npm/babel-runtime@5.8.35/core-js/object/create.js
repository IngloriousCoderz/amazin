/* */ 
module.exports = { "default": require("core-js/library/fn/object/create"), __esModule: true };