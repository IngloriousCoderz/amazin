/* */ 
module.exports = require('./object/index');
