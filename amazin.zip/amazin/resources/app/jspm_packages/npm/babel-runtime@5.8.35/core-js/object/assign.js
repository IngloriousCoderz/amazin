/* */ 
module.exports = { "default": require("core-js/library/fn/object/assign"), __esModule: true };