define(["github:mholt/PapaParse@4.1.2/papaparse.js"], function(main) {
  return main;
});