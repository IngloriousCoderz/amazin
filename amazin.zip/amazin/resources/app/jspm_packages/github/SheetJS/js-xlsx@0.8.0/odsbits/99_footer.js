/* */ 
})(typeof exports !== 'undefined' ? exports : ODS);
